function Contact() {
    return (
      <div style={{ padding: 20 }}>
        <h2>Contact View</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adip.</p>
      </div>
    );
  }

  export default Contact;